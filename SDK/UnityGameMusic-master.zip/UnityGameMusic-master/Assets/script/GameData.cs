﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameData {

	public static long score;
	public static float gagePoint;
}